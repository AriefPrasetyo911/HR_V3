"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateEmailDto = void 0;
class CreateEmailDto {
}
exports.CreateEmailDto = CreateEmailDto;
