"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateSupervisorDto = void 0;
class CreateSupervisorDto {
}
exports.CreateSupervisorDto = CreateSupervisorDto;
