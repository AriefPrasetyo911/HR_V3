"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Role = void 0;
var Role;
(function (Role) {
    Role["DEV"] = "DEV";
    Role["HR"] = "HR";
    Role["SUPERVISOR"] = "SUPERVISOR";
    Role["EMPLOYEE"] = "EMPLOYEE";
})(Role || (exports.Role = Role = {}));
