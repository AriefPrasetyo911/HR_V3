"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateAuthDto = void 0;
class CreateAuthDto {
}
exports.CreateAuthDto = CreateAuthDto;
