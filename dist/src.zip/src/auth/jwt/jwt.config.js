"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JwtConfig = void 0;
exports.JwtConfig = {
    user_secret: "4ff3dWsbOUpMvR222DCTIomW8DmiU3ZUJ4rVnM8HvYWYMX84",
    user_expired: '10m',
};
