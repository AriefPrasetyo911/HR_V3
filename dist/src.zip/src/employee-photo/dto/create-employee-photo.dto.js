"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateEmployeePhotoDto = void 0;
class CreateEmployeePhotoDto {
}
exports.CreateEmployeePhotoDto = CreateEmployeePhotoDto;
