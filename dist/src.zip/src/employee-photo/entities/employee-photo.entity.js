"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmployeePhoto = void 0;
class EmployeePhoto {
}
exports.EmployeePhoto = EmployeePhoto;
