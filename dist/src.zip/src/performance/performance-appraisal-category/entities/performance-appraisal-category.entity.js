"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PerformanceAppraisalCategory = void 0;
class PerformanceAppraisalCategory {
}
exports.PerformanceAppraisalCategory = PerformanceAppraisalCategory;
