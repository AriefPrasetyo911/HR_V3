"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PerformanceApraisalComment = void 0;
class PerformanceApraisalComment {
}
exports.PerformanceApraisalComment = PerformanceApraisalComment;
