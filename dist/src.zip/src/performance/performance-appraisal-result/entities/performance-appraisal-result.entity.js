"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PerformanceAppraisalResult = void 0;
class PerformanceAppraisalResult {
}
exports.PerformanceAppraisalResult = PerformanceAppraisalResult;
