"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PerformanceAppraisalQuestion = void 0;
class PerformanceAppraisalQuestion {
}
exports.PerformanceAppraisalQuestion = PerformanceAppraisalQuestion;
