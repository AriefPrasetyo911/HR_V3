"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PerformanceAppraisalYear = void 0;
class PerformanceAppraisalYear {
}
exports.PerformanceAppraisalYear = PerformanceAppraisalYear;
