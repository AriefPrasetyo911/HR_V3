"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PerformanceAppraisal = void 0;
class PerformanceAppraisal {
}
exports.PerformanceAppraisal = PerformanceAppraisal;
